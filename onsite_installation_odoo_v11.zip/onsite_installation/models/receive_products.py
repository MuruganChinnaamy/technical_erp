# -*- coding: utf-8 -*-

from odoo import api, fields, models
from datetime import datetime,date,timedelta
from dateutil.relativedelta import relativedelta
from odoo import tools, _
from odoo.exceptions import UserError, AccessError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from dateutil import parser
import math
import re
import calendar

class ReceiveProduct(models.Model):
    _name='receive.products'
    
    product_id          = fields.Many2one('product.product',string='Product')
    project_id          = fields.Many2one('project.project',string='Project')
    work_order_id       = fields.Many2one('job.order',string='Work order')
    dispatch_qty        = fields.Float(string='Dispatch Qty')
    dispatch_date       = fields.Date(string='Dispatch Date')
    packing_label       = fields.Char(string='Packing Label')
    received_qty        = fields.Float(string='Received Qty',compute='cal_received_qty')
    not_received_qty    = fields.Float(string='Not Received Qty',compute='cal_received_qty')
    rejected_qty        = fields.Float(string='Rejected Qty',compute='cal_received_qty')
    packet_received     = fields.Boolean(string='Packet Received',default=False)
    packet_not_received = fields.Boolean(string='Not Packet Received',default=False)
    line_actions        = fields.One2many('receive.products.actions','receive_products_id',string='Receive Products Actions')
    
    @api.depends('line_actions')
    def cal_received_qty(self):
        for record in self:
            received_qty     = 0.00
            not_received_qty = 0.00
            rejected_qty     = 0.00
            
            for line in record.line_actions:
                action = fields.Selection([('received','Received'),('not_received','Not Received'),('reject','Reject')])
                if line.action == 'received':
                    received_qty += line.quantity
                elif line.action == 'not_received':
                    not_received_qty += line.quantity
                else:
                    rejected_qty += line.quantity
            record.received_qty = received_qty
            record.not_received_qty = not_received_qty
            record.rejected_qty = rejected_qty
            
    
    @api.multi
    def to_action(self):
        for record in self:
            form_view = self.env.ref('onsite_installation.receive_products_actions_form')
            tree_view = self.env.ref('onsite_installation.receive_products_actions_tree')
            value = {
                'view_type': 'form',
                'view_mode': 'form',
                'name':'Actions',
                'res_model': 'receive.products.actions',
                'view_id': False,
                'views': [(form_view and form_view.id or False, 'form'),
                           (tree_view and tree_view.id or False, 'tree')],
                'type': 'ir.actions.act_window',
                'target': 'new',
                'nodestroy': True
             }
            return value
        
    @api.multi
    def to_view(self):
        for record in self:
            form_view = self.env.ref('onsite_installation.receive_products_actions_form')
            tree_view = self.env.ref('onsite_installation.receive_products_actions_tree')
        
            return {
                    'name': 'Actions',
                    'type': 'ir.actions.act_window',
                    'view_type': 'form',
                    'view_mode': 'tree,form',
                    'res_model': 'receive.products.actions',
                    'views': [(tree_view.id, 'tree')],            
                    'target': 'new',
                    'domain' : [('id', 'in', record.line_actions.ids)],
                    }
                
    
            
    @api.multi
    def action_packet_received(self):
        for record in self:
            record.packet_received = True
    
    @api.multi
    def not_action_packet_received(self):
        for record in self:
            record.packet_not_received = True
    
    
class ReceiveProductsActions(models.Model):
    _name='receive.products.actions'
    
    receive_products_id = fields.Many2one('receive.products')
    action = fields.Selection([('received','Received'),('not_received','Not Received'),('reject','Reject')])
    action_date = fields.Date(string='Action Date',default=datetime.today().date())
    action_by = fields.Many2one('res.users',string='Action By', default=lambda self: self.env.user)
    quantity = fields.Float(string='Quantity')
    
    @api.multi
    def to_submit(self):
        for record in self:
            context = record.env.context
            parent_id = context.get('active_id')
            if parent_id:
                new = record.create({
                                'receive_products_id':parent_id,
                                'action':record.action,
                                'action_date':record.action_date,
                                'action_by':record.action_by.id,
                                'quantity':record.quantity,
                                })
                
    @api.multi
    def to_close(self):
        for record in self:
            tree_view = self.env.ref('onsite_installation.receive_products_tree')
            return {
                    'name': 'Receive Products',
                    'type': 'ir.actions.act_window',
                    'view_type': 'form',
                    'view_mode': 'tree,form',
                    'res_model': 'receive.products',
                    'views': [(tree_view.id, 'tree')],            
                    'target': 'new',
                    'domain' : [('id', 'in', record.line_actions.ids)],
                    }            
                
                
    
class JobOrder(models.Model):
    _name='job.order'
    
    name = fields.Char('Name')
