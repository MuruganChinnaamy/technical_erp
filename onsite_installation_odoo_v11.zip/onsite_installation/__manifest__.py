# -*- coding: utf-8 -*-
{
    'name': 'Onsite Installation',
    'version': '11.0.2.4.0',
    'license': 'LGPL-3',
    'category': 'Demo',
    "sequence": 1,
    'summary': '',
    'author': 'Murugan',
    'maintainer': 'Murugan',
    'company': 'S&V',
    'website': 'https://www.odoo.com',
    'complexity': "easy",
    'description': """
        Description    ======
    """,
    'depends': ['base','product','project'], 
    'data': [
        
        'security/security.xml',
        'views/receive_products.xml',
    ],
    'qweb': [],
    'installable': True,
    'auto_install': False,
    'application': True,
}
